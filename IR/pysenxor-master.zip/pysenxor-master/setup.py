#!/usr/bin/env python3
#
# Copyright (C) 2019-2022  Stanislav Markov, Meridian Innovation Ltd, Hong Kong

from setuptools import setup
import sys
import os

if sys.version_info < (3, 6, 0, 'final', 0):
    raise SystemExit('Python 3.6 is required!')

_install_requires = [
    'pyserial',
    'numpy',
    'crcmod',
    'opencv-python',
    'imutils',
    'matplotlib',
    'cmapy'
]

setup(
    name="pysenxor",
    version="1.4.1",
    description="Python SDK for Meridian Innovation's SenXor.",
    author="Stanislav Markov, Meridian Innovation Ltd.",
    platforms="platform independent",
    package_dir={"": "."},
    packages=[
        "senxor",
    ],
    scripts=[],
    classifiers=[
        "Programming Language :: Python",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering",
    ],
    install_requires = _install_requires,
)
